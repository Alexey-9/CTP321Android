package ru.ctplab.android

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.MessageDigest

/** Early prototype: safe binary file viewer/editor. Calibration-map decoding is not implemented yet. */
class MainActivity : Activity() {
    private val openRequest = 101
    private val saveRequest = 102
    private val calibrationRequest = 103
    private val compareRequest = 104
    private val previewLimit = 4096 // Only this prefix is editable in this prototype
    private var sourceUri: Uri? = null
    private var originalBytes: ByteArray = byteArrayOf()
    private var calibrationBytes: ByteArray = byteArrayOf()
    private var calibrationName: String = "Описание калибровок не выбрано"
    private var comparisonBytes: ByteArray = byteArrayOf()
    private var comparisonName: String = "Второй BIN не выбран"
    private var displayedBytes: Int = 0
    private lateinit var fileLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var hexInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 36, 58)
        window.navigationBarColor = android.graphics.Color.rgb(16, 36, 58)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            setBackgroundColor(android.graphics.Color.rgb(245, 247, 250))
        }
        val title = TextView(this).apply {
            text = "CTP Mobile Lab"
            textSize = 24f; setTextColor(android.graphics.Color.rgb(16, 36, 58)); typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Тестовая версия 0.6.1 · без записи в ЭБУ"
            textSize = 14f; setTextColor(0xff526174); setPadding(0, dp(3), 0, dp(12))
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actions.addView(actionButton("Открыть файл") { chooseOpen() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(space(8), LinearLayout.LayoutParams(dp(8), 1))
        actions.addView(actionButton("Сохранить как…") { saveCopy() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        fileLabel = TextView(this).apply {
            text = "Файл не выбран"; textSize = 14f; setTextColor(0xff263445)
            setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundColor(0xffffffff)
        }
        statusLabel = TextView(this).apply {
            text = "Открой .bin, .j7 или другой бинарный файл."
            textSize = 13f; setTextColor(0xff526174); setPadding(0, dp(10), 0, dp(10))
        }
        val hexTitle = TextView(this).apply {
            text = "HEX-редактор первых $previewLimit байт"; textSize = 16f
            typeface = Typeface.DEFAULT_BOLD; setTextColor(0xff10243a); setPadding(0, dp(4), 0, dp(6))
        }
        hexInput = EditText(this).apply {
            hint = "Здесь появится HEX-код файла"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            typeface = Typeface.MONOSPACE; textSize = 12f; gravity = Gravity.TOP or Gravity.START
            setTextColor(0xff142333); setBackgroundColor(0xffffffff); setPadding(dp(10), dp(10), dp(10), dp(10))
            setHorizontallyScrolling(false); minLines = 12
        }
        val warning = TextView(this).apply {
            text = "Важно: карты калибровок пока не распознаны. Изменяй HEX только если понимаешь структуру файла. Перед экспериментами сохраняй резервную копию. Запись в ЭБУ ещё не реализована."
            textSize = 12f; setTextColor(0xff8a4b00); setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(0xfffff1d6)
        }
        root.addView(title); root.addView(subtitle); root.addView(actions)
        val calibrationActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        calibrationActions.addView(actionButton("Открыть .j7") { chooseCalibration() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        calibrationActions.addView(space(8), LinearLayout.LayoutParams(dp(8), 1))
        calibrationActions.addView(actionButton("Проверить пару") { analyzePair() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(space(8)); root.addView(calibrationActions)
        root.addView(actionButton("Анализировать описание .j7") { scanCalibrationLabels() }, LinearLayout.LayoutParams(-1, dp(40)))
        root.addView(space(8))
        root.addView(actionButton("Сравнить с другим BIN") { chooseComparison() }, LinearLayout.LayoutParams(-1, dp(40)))
        root.addView(space(10)); root.addView(fileLabel); root.addView(statusLabel); root.addView(hexTitle)
        root.addView(hexInput, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(space(8)); root.addView(warning)
        setContentView(root)
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 14f
        setOnClickListener { action() }
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** Structural inspection of the separately loaded CTM description; does not claim to decode calibration records. */
    private fun scanCalibrationLabels() {
        if (calibrationBytes.isEmpty()) { toast("Сначала открой файл описания .j7"); return }
        if (!hasCtmSignature(calibrationBytes)) {
            toast("Описание не имеет сигнатуры CTM"); return
        }
        val bytes = calibrationBytes
        val charset = java.nio.charset.Charset.forName("windows-1251")
        val candidates = mutableListOf<Pair<Int, String>>()
        val run = java.io.ByteArrayOutputStream()
        var runStart = 0
        fun allowed(v: Int): Boolean = v in 0x20..0x7e || v in 0xc0..0xff || v == 0xa8 || v == 0xb8 || v == 0xa0
        fun flushRun(endOffset: Int) {
            if (run.size() == 0) { runStart = endOffset + 1; return }
            val raw = String(run.toByteArray(), charset).replace('\u00a0', ' ')
            val value = raw.trim().trim(' ', '\'', '\"', '!', '#', '$', '%', '&', '*', '+', '-', '.', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~')
            val labelOffset = runStart + maxOf(0, raw.indexOf(value))
            run.reset()
            val cyrillic = value.count { it in 'А'..'я' || it == 'Ё' || it == 'ё' }
            val letters = value.count { it.isLetter() }
            if (value.length >= 8 && cyrillic >= 4 && letters >= 6 && cyrillic * 100 / maxOf(1, letters) >= 45 && !value.contains('�')) {
                if (candidates.none { it.second == value }) candidates.add(labelOffset to value)
            }
            runStart = endOffset + 1
        }
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xff
            if (allowed(v)) {
                if (run.size() == 0) runStart = i
                run.write(v)
            } else flushRun(i)
        }
        flushRun(bytes.size)
        val digest = sha256(bytes)
        val headerBytes = bytes.copyOfRange(0, minOf(32, bytes.size)).joinToString(" ") { "%02X".format(it.toInt() and 0xff) }
        val header = "Размер: ${bytes.size} байт\nSHA-256: $digest\nСигнатура: CTM\nПервые байты (hex):\n$headerBytes\nНайдено уникальных русских подписей: ${candidates.size}\n\n"
        val body = if (candidates.isEmpty()) "Читаемые подписи не найдены." else candidates.take(350).joinToString("\n\n") { (offset, label) ->
            val from = maxOf(0, offset - 8)
            val to = minOf(bytes.size, offset + 24)
            val context = bytes.copyOfRange(from, to).joinToString(" ") { "%02X".format(it.toInt() and 0xff) }
            "0x${offset.toString(16).uppercase().padStart(6, '0')}  $label\n   HEX [0x${from.toString(16).uppercase()}..0x${to.toString(16).uppercase()}): $context"
        }
        val note = "\n\nОграничение: это строки контейнера и байтовый контекст, а не декодированные записи карт. Адреса BIN, оси, типы чисел и масштабы не установлены."
        val content = TextView(this).apply {
            text = header + body + (if (candidates.size > 350) "\n\n… показаны первые 350" else "") + note
            textSize = 12f; setTextColor(0xff263445); setPadding(dp(16), dp(8), dp(16), dp(8)); typeface = Typeface.MONOSPACE
        }
        val scroll = ScrollView(this).apply { addView(content) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Анализ CTM · ${candidates.size} подписей")
            .setView(scroll)
            .setPositiveButton("Закрыть", null)
            .show()
    }

    private fun chooseComparison() {
        if (originalBytes.isEmpty()) { toast("Сначала открой основной BIN"); return }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, compareRequest)
    }

    /** Byte-by-byte comparison for reverse engineering; does not infer map meaning. */
    private fun compareBinaries() {
        if (originalBytes.isEmpty() || comparisonBytes.isEmpty()) { toast("Выбери оба BIN-файла"); return }
        val common = minOf(originalBytes.size, comparisonBytes.size)
        val changed = mutableListOf<Int>()
        for (i in 0 until common) if (originalBytes[i] != comparisonBytes[i]) changed.add(i)
        val ranges = mutableListOf<Pair<Int, Int>>()
        if (changed.isNotEmpty()) {
            var start = changed[0]; var prev = start
            for (i in changed.drop(1)) {
                if (i > prev + 1) { ranges.add(start to prev); start = i }
                prev = i
            }
            ranges.add(start to prev)
        }
        val report = buildString {
            append("Файл A: ${sourceUri?.lastPathSegment ?: "основной BIN"}\nРазмер: ${originalBytes.size} байт\nSHA-256: ${sha256(originalBytes)}\n\n")
            append("Файл B: $comparisonName\nРазмер: ${comparisonBytes.size} байт\nSHA-256: ${sha256(comparisonBytes)}\n\n")
            append("Различающихся байт в общей части: ${changed.size} из $common\n")
            append("Разница длины: ${comparisonBytes.size - originalBytes.size} байт\n\n")
            if (ranges.isEmpty()) append("В общей части файлы идентичны.") else {
                append("Диапазоны изменений (смещения HEX, первые 500 диапазонов):\n")
                for ((a, b) in ranges.take(500)) {
                    append("0x${a.toString(16).uppercase().padStart(6, '0')}–0x${b.toString(16).uppercase().padStart(6, '0')}  (${b-a+1} байт)\n")
                    val from = maxOf(0, a - 4); val to = minOf(common, b + 5)
                    append(" A: ")
                    append(originalBytes.copyOfRange(from, to).joinToString(" ") { "%02X".format(it.toInt() and 0xff) })
                    append("\n B: ")
                    append(comparisonBytes.copyOfRange(from, to).joinToString(" ") { "%02X".format(it.toInt() and 0xff) })
                    append("\n\n")
                }
                if (ranges.size > 500) append("… скрыто ещё ${ranges.size - 500} диапазонов\n")
            }
            append("\nВажно: совпадение/различие байтов само по себе не определяет карты, оси или коэффициенты.")
        }
        val view = TextView(this).apply {
            text = report; textSize = 12f; typeface = Typeface.MONOSPACE
            setTextColor(0xff263445); setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        android.app.AlertDialog.Builder(this).setTitle("Сравнение BIN")
            .setView(ScrollView(this).apply { addView(view) })
            .setPositiveButton("Закрыть", null).show()
    }

    private fun chooseCalibration() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, calibrationRequest)
    }

    private fun analyzePair() {
        if (originalBytes.isEmpty()) { toast("Сначала открой BIN-прошивку") ; return }
        if (calibrationBytes.isEmpty()) { toast("Открой файл описания .j7") ; return }
        val binHash = sha256(originalBytes)
        val mapHash = sha256(calibrationBytes)
        val binCt = hasCtmSignature(originalBytes)
        val mapCt = hasCtmSignature(calibrationBytes)
        val marker = findAsciiMarker(originalBytes)
        val report = buildString {
            append("ПАРА ФАЙЛОВ\n\n")
            append("BIN: ${sourceUri?.lastPathSegment ?: "файл"}\nРазмер: ${originalBytes.size} байт\nSHA-256: $binHash\n")
            append("Сигнатура CTM: ${if (binCt) "да" else "нет — ожидаемо для raw BIN"}\n")
            append("Внутренняя строка: ${marker ?: "не найдена"}\n\n")
            append("Описание: $calibrationName\nРазмер: ${calibrationBytes.size} байт\nSHA-256: $mapHash\n")
            append("Сигнатура CTM: ${if (mapCt) "да" else "нет"}\n\n")
            append("Результат: файлы собраны в рабочую пару по подтверждению пользователя.\n")
            append("Автоматическая адресная привязка карт к BIN пока не выполнена. Этот отчёт не подтверждает адреса, оси, типы или масштабы значений; редактирование калибровок пока отключено.")
        }
        android.app.AlertDialog.Builder(this).setTitle("Анализ пары BIN + J7")
            .setMessage(report).setPositiveButton("Закрыть", null).show()
    }

    private fun hasCtmSignature(bytes: ByteArray): Boolean = bytes.size >= 3 &&
        bytes[0] == 0x43.toByte() && bytes[1] == 0x54.toByte() && bytes[2] == 0x4d.toByte()

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }

    private fun findAsciiMarker(bytes: ByteArray): String? {
        val ascii = String(bytes, Charsets.ISO_8859_1)
        val match = Regex("j7[a-z0-9_.]{3,24}", RegexOption.IGNORE_CASE).find(ascii)
        return match?.value
    }

    private fun chooseOpen() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, openRequest)
    }

    private fun saveCopy() {
        if (originalBytes.isEmpty()) { toast("Сначала открой файл"); return }
        val parsed = parseHex(hexInput.text.toString())
        if (parsed == null) { toast("HEX должен содержать только пары байт, разделённые пробелами/переносами строк"); return }
        if (parsed.size != displayedBytes) {
            toast("Сохранение отменено: введено ${parsed.size} байт, а в окне должно быть ровно $displayedBytes. Размер файла не менялся.")
            return
        }
        val merged = originalBytes.copyOf()
        System.arraycopy(parsed, 0, merged, 0, displayedBytes)
        val name = (sourceUri?.lastPathSegment?.substringAfterLast(':') ?: "firmware.bin").substringAfterLast('/')
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, if (name.contains('.')) "edited_$name" else "edited_firmware.bin")
        }
        pendingSaveBytes = merged
        startActivityForResult(intent, saveRequest)
    }

    private var pendingSaveBytes: ByteArray? = null

    @Deprecated("Use Activity Result API in a production build")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == calibrationRequest) {
                calibrationBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать описание")
                calibrationName = uri.lastPathSegment ?: "J7"
                statusLabel.text = "BIN: ${originalBytes.size} байт · описание: $calibrationName (${calibrationBytes.size} байт)"
                toast("Описание калибровок загружено")
            } else if (requestCode == openRequest) {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать файл")
                sourceUri = uri; originalBytes = bytes; displayedBytes = minOf(bytes.size, previewLimit)
                fileLabel.text = "${uri.lastPathSegment ?: "Выбранный файл"} · ${bytes.size} байт"
                val header = if (bytes.size >= 3 && bytes[0] == 0x43.toByte() && bytes[1] == 0x54.toByte() && bytes[2] == 0x4d.toByte()) "CTM-подобный контейнер (заголовок CTM)" else "Бинарный файл"
                statusLabel.text = "$header · показываются первые $displayedBytes байт из ${bytes.size}"
                hexInput.setText(toHex(bytes.copyOfRange(0, displayedBytes)))
            } else if (requestCode == compareRequest) {
                comparisonBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать второй файл")
                comparisonName = uri.lastPathSegment ?: "Второй BIN"
                compareBinaries()
            } else if (requestCode == saveRequest) {
                val bytes = pendingSaveBytes ?: return
                contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } ?: error("Не удалось сохранить файл")
                toast("Копия сохранена: ${bytes.size} байт")
                pendingSaveBytes = null
            }
        } catch (e: Exception) { toast("Ошибка: ${e.message ?: "неизвестная ошибка"}") }
    }

    private fun toHex(bytes: ByteArray): String = bytes.asList().chunked(16).mapIndexed { row, chunk ->
        chunk.joinToString(" ") { "%02X".format(it.toInt() and 0xff) }
    }.joinToString("\n")

    private fun parseHex(text: String): ByteArray? {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return null
        // Accept only byte tokens like "3A FF 01"; reject silently-stripped letters/punctuation.
        val tokens = trimmed.split(Regex("\\s+"))
        if (tokens.any { !it.matches(Regex("(?i)([0-9a-f]{2}|0x[0-9a-f]{2})")) }) return null
        return try { ByteArray(tokens.size) { i -> tokens[i].removePrefix("0x").removePrefix("0X").toInt(16).toByte() } } catch (_: Exception) { null }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
