plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.ctplab.android"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.ctplab.android"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "0.6.1"
    }
}
